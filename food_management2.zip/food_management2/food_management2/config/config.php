<?php
define("db_servername", "food-management.c98mk444qjrw.eu-central-1.rds.amazonaws.com");
define("db_username","appuser");
define("db_password","Food1205");
define("db_database", "food_management");