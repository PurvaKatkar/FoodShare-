$('#subjectTable').DataTable();
$('#deptTable').DataTable();